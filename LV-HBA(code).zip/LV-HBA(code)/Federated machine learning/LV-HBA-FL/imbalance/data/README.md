# Data

MNIST & CIFAR-10 datasets will be downloaded automatically by the torchvision package.
